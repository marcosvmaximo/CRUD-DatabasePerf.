using CRUD;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Adiciona os serviços necessários ao contêiner
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Adiciona suporte aos controllers
builder.Services.AddControllers(); // Isso registra os serviços de controllers

// Pega a connection string do appsettings.json
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Configura o DbContext usando MySQL e Pomelo
builder.Services.AddDbContext<DataContext>(opt => opt
    .UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

// Cria o app
var app = builder.Build();

// Configura o Swagger apenas no ambiente de desenvolvimento
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization(); // Adiciona autorização se necessário

// Mapeia os controllers
app.MapControllers();  // Aqui é onde o erro acontece se 'AddControllers()' não for chamado

app.Run();