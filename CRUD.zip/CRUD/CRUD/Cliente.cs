using System.ComponentModel.DataAnnotations;

namespace CRUD;

public class Cliente
{
    [Key]
    [Required]
    public int Id { get; set; }
    
    [StringLength(50)]
    [Required]
    public string Nome { get; set; }
    
    [Required]
    public DateTime DataNascimento { get; set; }
    
    [StringLength(50)]
    [Required]
    public string Telefone { get; set; }
    
    [StringLength(50)]
    [Required]
    public string Endereco { get; set; }
}